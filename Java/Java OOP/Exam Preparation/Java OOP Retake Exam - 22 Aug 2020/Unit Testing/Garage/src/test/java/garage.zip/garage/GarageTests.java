package garage;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class GarageTests {
    private List<Car> cars;
    private Garage garage;

    @Before
    public void setUp() {
        cars = new ArrayList<>();
        garage = new Garage();
    }

    @Test
    public void testAddCarWithValidObject() {
        Car car = new Car("Ferrari", 300, 2000000);
        cars.add(car);
        Assert.assertEquals(1, cars.size());
    }

    @Test
    public void testGetMostExpensiveCar() {
        Car car = new Car("Ferrari", 300, 2000000);
        Car car1 = new Car("Opel", 300, 3000000);
        cars.add(car);
        cars.add(car1);

        garage.addCar(car);
        garage.addCar(car1);

        Car mostExpensive = garage.getTheMostExpensiveCar();

        Assert.assertEquals(car1,mostExpensive);
        

    }


}